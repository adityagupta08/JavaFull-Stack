import {Mobile} from '../Mobile';

export class BasicPhone extends Mobile{

    constructor(id,name,cost,private type:string){
        super(id,name,cost);
        this.type=type;

    }

    printAllData()
    {
        super.printAllData();
        console.log(`Mobile Type : ${this.type}`);

    }
    
}