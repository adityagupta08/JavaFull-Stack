export class Mobile{
    constructor(private id:number,private name:string,private cost:number)
    {
        this.id=id;
        this.name=name;
        this.cost=cost;
    }

    printAllData()
    {
        console.log(`Mobile Id : ${this.id} 
 Mobile Name : ${this.name}
 Mobile Cost : ${this.cost}      
        `)
    }
}