import {Mobile} from '../Mobile';
import {SmartPhone} from '../SmartPhone';
import {BasicPhone} from '../BasicPhone';


var mob1:SmartPhone = new SmartPhone(101,"Samsung",120000,"SmartPone");

var mob2:BasicPhone = new BasicPhone(101,"Oppoo",130000,"BasicPone");

mob1.printAllData();
mob2.printAllData();




