import React, { Component } from 'react';
import './App.css';
import Projects from './components/projects'
import AddProject from './components/addproject'
import uuid from 'uuid';
import $ from 'jquery';
import Todos from'./components/Todos';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Home from './components/Home';
import Login from './components/Login';

class App extends Component {
  constructor() {
    super();
    this.state = {
      projects: []
    };
  }
  componentWillMount(){
    console.log("componentWillMount executed");
    this.setState({

      projects: [
        {
          id:uuid.v4(),
          title: 'Business Website',
          category: 'Web Design',
          projectManager: 'Shri Ram',
          details: [{
            id: 1,
            duration: '10 days',
            budget: '2 lakh'
          },
          {
            id: 2,
            duration: '100 days',
            budget: '20 lakh'
          }
          ]
        },
        {
          id:uuid.v4(),
          title: 'Socia App',
          category: 'App Development',
          projectManager: 'Shruti Dev',
          details: [{
            id: 3,
            duration: '20 days',
            budget: '4 lakh'
          },
          {
            id: 4,
            duration: '200 days',
            budget: '40 lakh'
          }
          ]
        },
        {
          id:uuid.v4(),
          title: 'Shopping Cart',
          category: 'Web Development',
          projectManager: 'Sonali Singh',
          details: [{
            id: 5,
            duration: '30 days',
            budget: '6 lakh'
          },
          {
            id: 6,
            duration: '300 days',
            budget: '60 lakh'
          }
          ]
        }
      ]
    })
 
   
 }
/*  ============Fetching json data===================== */
componentDidMount()
{
  this.getToDos();     
}
 getToDos() {

    $.ajax({

      url: 'https://jsonplaceholder.typicode.com/todos',

      dataType: 'json',

      cache: false,

      success: function (data) {

        this.setState({ todos: data }, function () {

          console.log(this.state);

        });

      }.bind(this),

      error: function (xhr, status, err) {

        console.log(err);

      }

    });

  }


  handleAddProject(newp){
    
    let proj =this.state.projects;
    proj.push(newp);

    
    console.log(newp);
    console.log(proj);
    
    

    this.setState({projects:proj});
    
  }

  handleDeleteProject(id)
  {
    let projects= this.state.projects
    let index = projects.findIndex(obj=>obj.id===id)
    projects.splice(index,1);
    this.setState({projects:projects})
    
  }

  render() {
    return (
      
      <div className="App">

      <Router>
            <div>
               <h2>Welcome to React Router Tutorial</h2>
               <ul>
                  <li><Link to={'/'}>Home</Link></li>
                  <li><Link to={'/Login'}>Login</Link></li>
               </ul>
               <hr />
               
               <Switch>
                  <Route exact path='/' component={Home} />
                  <Route exact path='/Login' component={Login} />
               </Switch>
            </div>
         </Router>




        <h1>My React App</h1>
        <AddProject addProject={this.handleAddProject.bind(this)}/>
        <Projects projects={this.state.projects} onDelete={this.handleDeleteProject.bind(this)} />
        <Todos todos={this.state.todos}/>


      </div>
    );
  }
}

export default App;
