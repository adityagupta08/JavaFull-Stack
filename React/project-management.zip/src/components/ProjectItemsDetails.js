import React, { Component } from 'react';


class ProjectItemsDetails extends Component {
  render() {
    return (
        <ul>
        <li>{this.props.projectDetails.duration}
        {this.props.projectDetails.budget}</li>
        </ul>
    );
  }
}

export default ProjectItemsDetails;
