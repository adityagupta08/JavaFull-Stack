import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>Hello {{name}} </h1><br/>
  <button (click)="increment()" class="increment">Increment</button>
  <button (click)="decrement()" class="decrement">Decrement</button><br/>
  <h2>{{value}}  {{message}}</h2>`
})
export class AppComponent { 
  value:number=0;
  message:string;
  name = 'Vaishali'; 
  increment(){
    if(this.value<15){
      this.value+=1;
      this.message=' ';
    }
    else{
      this.message='Maximum reached!';
    }
  }
}
