export function greet(name) {
  return 'Hello, ' + name;
}