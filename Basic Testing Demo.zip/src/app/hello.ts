export function hello()
{
    return "Hello World";
}

export function greetMe(name)
{
    return "Hello "+name;
}

export function compute(number) {
  if (number < 0) {
    return 0;
  }

  return number + 1;
}

export class AuthService
{
    isAuthenticate():boolean
    {
        return !!localStorage.getItem('token');
    }
}