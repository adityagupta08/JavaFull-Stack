import {TestBed,async,ComponentFixture} from '@angular/core/testing';
import {AppComponent} from './app.component';
import {DebugElement} from '@angular/core';
import {By} from '@angular/platform-browser'

describe("Testing App Component",()=>{
    let app:AppComponent;
    let debugElement:DebugElement;
    let componentInstance:AppComponent;
    let fixture:ComponentFixture<AppComponent>;
    /*--------------------------------------*/
    beforeEach(async()=>{
        TestBed.configureTestingModule({
            declarations:[AppComponent]
        }).compileComponents();

        /************************************* */

        


    });

    /*--------------------------------------*/

    beforeEach(()=>{
        fixture=TestBed.createComponent(AppComponent);
        debugElement=fixture.debugElement;
        app=fixture.debugElement.componentInstance;
    });

    /*--------------------------------------*/
    it("Should create App Component",()=>{
        expect(app).toBeTruthy();
    });

    /*--------------------------------------*/

    it("Check whether name is rendered in h1 tag",
    async()=>{
        const fix=TestBed.createComponent(AppComponent);
        fix.detectChanges();
        const compElement=fix.debugElement.nativeElement;
        expect(compElement.querySelector("h1").textContent).toContain("Hello Vaishali");
    });

    /*--------------------------------------*/

    it("Should increment value by 1 in template",async()=>{
        debugElement.query(By.css("button.increment")).triggerEventHandler("click",null);
        fixture.detectChanges();
        const value=debugElement.query(By.css("h2")).nativeElement.innerText;
        expect(value).toEqual('1');
    });
});