import {hello} from './hello'
import {greetMe} from './hello'
import {compute} from './hello'
import {AuthService} from './hello'




describe("This suite is for hello World",function()           // It is a Suite which containe multiple spec
// Two paarameters one spec name and another function
{


    let service:AuthService;
    /************************ */

    beforeEach(()=>{
        service=new AuthService();
    })

    /********************************* */

    afterEach(()=>{
        localStorage.removeItem('token');
        service=null;
    })









    /*********************************** */

    it("hello function returns Hello World",function()        // It is a spec also known as testor testing      
    {
        expect(hello()).toEqual("Hello World")              // toEqual is a Matcher and we are expecting returning of "Hello World" through
                                                            // hello() function and match it with toEqual matcher parameter
    });
    /******************************************* */

    it("should include the name in the message",()=>
    {
        const name='Vaishali';
        expect(greetMe(name)).toContain(name)
    });

    /******************************************* */

    it("should increment input if it is positive",()=>
    {
        const result=compute(1);
        expect(result).toBe(2)
    })

      it("should return 0 input if it is negative",()=>
    {
        const result=compute(-1);
        expect(result).toBe(0)
    })
    

    /************************************************ */
    it("should return Authentication , when there is a token",()=>
    {
       localStorage.setItem('token','1234');
        expect( service.isAuthenticate()).toBeTruthy();
    })
    /****************************************************** */
    it("should return Falsy Authentication , when there is a token",()=>
    {
      //localStorage.setItem('token','78979');
        expect( service.isAuthenticate()).toBeFalsy();
    })

});

/////////*********** *****************/

