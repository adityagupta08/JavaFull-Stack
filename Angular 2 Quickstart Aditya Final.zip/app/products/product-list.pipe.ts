import {IProduct} from './product'

import {PipeTransform,Pipe} from 'angular2/core'

@Pipe(
 {
    name:'productFilter'
 })


// PipeTransform is a Interface and 
//transform is a method in it

export  class ProductFilterPipe implements PipeTransform
{
    transform(value:IProduct[], args:string[])
    {
        // It first checks whether something is written in the text box or not

        let filter: string = args[0]?args[0].toLocaleLowerCase():null;

        // filter used after value is a function which accepts callback function
        // 


        return filter?value.filter(
            (product:IProduct)=>product.productName.toLocaleLowerCase().indexOf(filter) != -1

        ):value;


    }
}