import {Component,OnInit} from 'angular2/core';


import {IProduct} from './product';

import {ProductFilterPipe} from './product-list.pipe';
import {StarComponent} from '../shared/star.component';


@Component(
    {
        selector: 'pm-products',
        templateUrl: 'app/products/product-list.component.html',
        styleUrls:['app/products/product-list.component.css'],

        pipes:[ProductFilterPipe]
        directives:[StarComponent]
    }
)

export class ProductListComponent
{

     pageTitle: string = 'Product Lists';

     imageWidth:number=100;
     imageMargin:number=5;




     ngOnInit():void{

         console.log("Hello form OnInit")

       /*
        $.get("app/products/OnInit.txt",
        
        function(data,status)
        {
            console.log(data);
        }
        )
        */

     }





     showImage:boolean=false;
     toggleImage():void
     {
         this.showImage=!this.showImage;
     }


     listFilter:string='';



     products: IProduct[] = [

 

        {

            "productId": 2,
            "productName": "Garden Cart",
            "productCode": "GDN-0023",
            "releaseDate": "March 18, 2016",
            "description": "15 gallon capacity rolling garden cart",
            "Date": "12/2/2017",
            "price": 32.99,
            "starRating": 3.5,
            "imageUrl": "https://www.gstatic.com/webp/gallery3/1.png"

        },

        {

            "productId": 5,
            "productName": "Hammer",
            "productCode": "TBX-0048",
            "releaseDate": "May 21, 2016",
            "description": "Curved claw steel hammer",
            "Date": "2/3/2018",
            "price": 8.9,
            "starRating": 4.8,

            "imageUrl": "https://www.gstatic.com/webp/gallery3/2.png"

        }
     ];

     onRatingClicked(message:string):void
     {
         this.pageTitle='Product List: '+message
     }

    
}