function showDomain()
 
 {
	
	var domainObj = document.getElementById("txtDomain");
	var Alldomain = new Array("Select Domain", "JEE", ".NET");
	
	for(var i=0; i<Alldomain.length;i++)
	{
	
		domainObj.options[i]= new Option(Alldomain[i], Alldomain[i]);
	}
 
 
 }
 // This code is not working  in the browser
 // the same code which I made in assignments  is working but this code is showing the error (unexpected typeError)
 // 
 
 
function populateModule()
{
	
	var domainObj = window.document.Moduleform.txtDomain;
	var moduleObj = window.document.Moduleform.txtModule;
	var domainSelectedIndex = domainObj.selectedIndex;
	
	
	var moduleArray = new Array();
	moduleArray[1] = new Array("Core Java", "Servlet-JSP", "Spring");
	moduleArray[2] = new Array("C#","ADO.NET","ASP.NET");
	
	var x = moduleObj.length;
	for(var t=0;t<x;t++)
	{
		moduleObj.remove(0);
	
	}
	
	for(var i=0; i<moduleArray[domainSelectedIndex].length;i++)
		{
		
			moduleObj.options[i]= new Option(moduleArray[domainSelectedIndex][i],moduleArray[domainSelectedIndex][i]);
			
		
		}


}


function calculateScore()
{	
	var mpt = document.getElementById("txtMpt").value;
	var mtt = document.getElementById("txtMtt").value;
	var assign = document.getElementById("txtassign").value;
	
	var x =mpt*70;
	var y =mtt*40;
	var z= assign*15;
	
	
	var score= x+ ((3*y)/8) + z;
	alert("Your score is "+score);


}
 
 
 