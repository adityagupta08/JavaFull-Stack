var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');

//   Using Postman run localhost:5000/add  with POST selected
//     Set Headers value as  Key= Content-Type and value = application/json
//  In the Body Of Request type : 
//
//      {
//         "mobId": 1008,
//         "mobName": "Redmi Note 4",
//         "mobPrice": 8999
//     }
// This will add new Mobile in mobile.json file and displayed in console as well as sent 
// as a response to postman 


exp.use(parser.json())
exp.route('/add').post((req,res)=>{
    var raw = fs.readFileSync('mobile.json')
    var data = JSON.parse(raw);
console.log(req.body)
var obj = req.body;
console.log("Adding of New mobile :  "+obj);
data.push(obj)
res.send(data)

   
    fs.writeFileSync('mobile.json', JSON.stringify(data));
})

exp.use(cors()).listen(5000, ()=>console.log("RUNNING...."));