 function showStates()
 {
 
	var statesObj=window.document.regform.txtstate;
	
	var allStates =new Array("MS","UP","MP","AP");
	
	for( var i=0; i<allStates.length;i++)
	{	
		
		statesObj.options[i]= new Option(allStates[i],allStates[i]);
		
	
	}
	
 
 }
 
 function validateAllData()
 {
 
	var pwdData=window.document.regform.password.value;
	var confPwdData=window.document.regform.confpassword.value;
	
	if(pwdData!=confPwdData)
	{
		var confPwdErrSection=document.getElementById("confPwdErrSectionId");
		confPwdErrSection.innerHTML="Password and confirm pass should be same";
        return false;		


		
	}
	return true;
 
 
 
 
 
 }