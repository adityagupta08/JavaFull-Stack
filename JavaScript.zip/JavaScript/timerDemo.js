 function greetMe1()
 
 { 
	var time=window.setTimeout("getMsg()",3000);
 
	
 
 }
 
 function getMsg()
 {
 
	alert("Welcome to Capgemini");
 
 }
 function getMsg2()
 {
 
	alert("Happy to have you");
 
 }
 
 
 
 function greetMe2()
 {
	var time=window.setInterval("getMsg2()",2000);
 
 }