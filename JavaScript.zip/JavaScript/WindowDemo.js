function callMe()
{
	alert("i was loded");

}
 
 function greetMe()
 
 {
 
	var firstNameObj=document.getElementById("fname");
	var Firstname=firstNameObj.value;
	
	var mywindow1=window.open("","MyCgWindow1","width=500 ,height=400");
	
	mywindow1.document.write("<body bgcolor='pink'>");
	mywindow1.document.write("<h3>Welcome to Capgemini");
	mywindow1.document.write("</h3>"+Firstname);
	mywindow1.document.write("</body>");
 
 }
 
 function showNewFile()
 {
	
	var mywindow2=window.open("basicDemoJVscript.html","MyCgWindow2","width=500 ,height=400");
	
 }