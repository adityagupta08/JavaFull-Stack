 function addNumber()
 {
	var fnObj=document.getElementById("fnumber");
	var fn=eval(fnObj.value);
	
	var snObj=document.getElementById("Snumber");
	
	var sn=eval(snObj.value);
	
	var ad = fn + sn;
	
	document.getElementById("result").value=ad;
	
	
	
 }