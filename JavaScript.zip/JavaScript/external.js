var compName="CapGemini";
window.document.write("<font color='red' size='30px' >Welcome to :</font>");
window.document.write(compName);