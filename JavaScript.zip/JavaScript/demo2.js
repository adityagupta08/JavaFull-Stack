 var marksdata=window.prompt("Enter your marks:");
 
 var marks=eval(marksdata);
 
 
 if(marks<40)
 {
	window.alert("you are fail");
	
 }
 else if(marks>=40 && marks<60){
 
	window.alert("you got Second class");
 
 }
 else if(marks>=60 && marks<75){
 
	window.alert("you got First Class");
 
 }
 else if(marks>=75 && marks<100){
 
	window.alert("you got distinction");
 
 }
 else if(marks>=100){
 
	window.alert("you got not applicable");
 
 }
 var data=window.confirm("Do you want to confirm?");
 if(data==true)
 {
	alert("OK we will continue");
 }
 else {
	alert("ok No issue");
 }
 