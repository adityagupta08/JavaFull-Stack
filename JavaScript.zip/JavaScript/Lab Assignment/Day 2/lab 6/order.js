 function validation()
 {
	var Bd = document.getElementById("barbDoll").value;
	
	var Cal = document.getElementById("calc").value;
	var Mob = document.getElementById("MobPhn").value;
	var Lgdvd = document.getElementById("Lgdvd").value;
 
	if(Bd=="" && Cal=="" && Mob=="" && Lgdvd=="")
		{alert("no item selected");
		return false;
	}
	else
	{
		var mywindow=window.open("","Invoice", "width=500, height=300 top=200 left=300");
		
		mywindow.document.write("<body align='center'><h1 >INVOICE</h1><br/><table border='1' align='center'><tr><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL</th></tr> ");
		
		if(Bd!=undefined)
		{
			mywindow.document.write("<tr><td>Barbie Doll</td><td>"+Bd+"</td><td>20</td><td>"+Bd*20+"</td></tr>");
		}
		if(Cal!=undefined)
		{
			mywindow.document.write("<tr><td>Calculator</td><td>"+Cal+"</td><td>30</td><td>"+Cal*30+"</td></tr>");
		}
		if(Mob!=undefined)
		{
			mywindow.document.write("<tr><td>Mobile Phones</td><td>"+Mob+"</td><td>40</td><td>"+Mob*40+"</td></tr>");
		}
		if(Lgdvd!=undefined)
		{
			mywindow.document.write("<tr><td>LG DVD</td><td>"+Lgdvd+"</td><td>50</td><td>"+Lgdvd*50+"</td></tr>");
		}
		
		
		
		
		mywindow.document.write("</table></body>");
		
	}
 }
 
 