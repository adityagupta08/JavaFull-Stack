 function calculatePayment()
 {
	var amt= eval(document.getElementById("amount").value);
	var RoI= eval(document.getElementById("annualrate").value);
	var years= eval(document.getElementById("years").value);
	
	if(amt>1500000)
	{
		document.getElementById("amtErrSection").innerHTML="Amount of Loan should not be more than 15 Lakhs";
	}
	
	if(years<7 || years>15)
	{
		document.getElementById("repayErrSection").innerHTML="Repayment period should be between 7yrs to 15 yrs";
		
	}
 
	var si = (amt*RoI*years)/100;
	
	var totalPay= amt + si;
	var monPay= totalPay/(years*12);
	
	document.getElementById("monthlyPay").value=monPay;
	document.getElementById("totalPayment").value=totalPay;
	document.getElementById("totalInterest").value=si;
 
 
 }