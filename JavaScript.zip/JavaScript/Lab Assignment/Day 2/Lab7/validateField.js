 function showCategory()
 {
	var catObj     =  window.document.frmValidate.txtCat;
	var Allcategry = new Array("Select Product", "Electronics", "Grocery");
	
	for(var i=0; i<Allcategry.length;i++)
	{
		catObj.options[i]= new Option(Allcategry[i], Allcategry[i]);
	
	
	}
	
 }
 

 function populateProducts()
 {
	var catObj=window.document.frmValidate.txtCat;
	var proObj=window.document.frmValidate.prodId;
	var catSelectedIndex=catObj.selectedIndex;
	
	
	var productArr = new Array();
	
	productArr[1] = new Array("Laptop", "Television","Phone");
	productArr[2] = new Array("Soap", "Powder");
	var x = proObj.length;
	for(var j=0;j<x;j++)
	{
		proObj.remove(0);
	}
	
	
	for(var j=0;j<productArr[catSelectedIndex].length;j++)
	{
		proObj.options[j] = new Option(productArr[catSelectedIndex][j],productArr[catSelectedIndex][j]);
	}
	
 
 
 
 }
 
 function ResetFunc()
 {
	var selProdId=window.document.frmValidate.prodId;
	selProdId.options[0]=new Option("--------","none");
	selProdId.remove(1);
	selProdId.remove(1);
	
 
 
 }
 
 
 function SelQty()
 {
 
	var qty = document.getElementById("txtQtyId").value; 
	 var priceArray = new Array();
	 priceArray[1]=new Array(20000,30000,10000);
	 priceArray[2]=new Array(40,90);
	 
	 var selCatObj=window.document.frmValidate.txtCat;
	 
	 var selProObj=window.document.frmValidate.prodId;
	 
	 var selcat=selCatObj.selectedIndex;
	 var selpro= selProObj.selectedIndex;
	 
	 var price =eval((qty)*priceArray[selcat][selpro]);
	 
	 document.getElementById("txtTotPriceId").value=price;
 }
 
 function showInvoice()
 {
	var qty = eval(document.getElementById("txtQtyId").value); 
	
	var catItems= new Array("","Electronics", "Grocery");
	var proItems= new Array();
	proItems[1]= new Array("Laptop", "Television","Phone");
	proItems[2]= new Array("Soap","Powder");
	
	
	 var priceArray = new Array();
	 priceArray[1]=new Array(20000,30000,10000);
	 priceArray[2]=new Array(40,90);
	 
	 var selCatObj=document.frmValidate.txtCat;
	 
	 var selProObj=document.frmValidate.prodId;
	 
	 var selcat=selCatObj.selectedIndex;
	 var selpro= selProObj.selectedIndex;
	 
	 var price =eval((qty)*priceArray[selcat][selpro]);
	 
	
	
	if(qty=="")
		{alert("no item selected");
		return false;
	}
	else
	{
		var mywindow=window.open("","Invoice", "width=500, height=300 top=200 left=300");
		
		mywindow.document.write("<body align='center'><h1 >INVOICE</h1><br/><table border='1' align='center'><tr><th>CATEGORY</th><th>PRODUCT</th><th>QUANTITY</th><th>PRICE</th><th>TOTAL PRICE</th></tr> ");
		
		mywindow.document.write("<tr><td>"+catItems[selcat]+"</td><td>"+proItems[selcat][selpro]+"</td><td>"+qty+"</td><td>"+priceArray[selcat][selpro]+"</td><td>"+price+"</td></tr>");
		
		mywindow.document.write("</table></body>");
		
	}
 
 
 
 }
 
 
 
 
 
 
 
 
 
 