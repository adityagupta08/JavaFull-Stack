 function dispHello()
{
//TODO:return the string “Hello World“
var str= "<b>Hello World</b>"
document.write(str);
}
