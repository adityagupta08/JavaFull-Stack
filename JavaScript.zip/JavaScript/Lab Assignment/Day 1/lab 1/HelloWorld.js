 function sayHello()
{
	window.document.write("<h1 style='size:20px; color:red'> Hello World</h1>");
}
