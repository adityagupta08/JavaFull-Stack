  function convertName()
  {
  
	var fname= document.getElementById("txtFNameId").value;
	var fnameCObj= document.getElementById("txtFNameCId");
	
	fnameCObj.value=fname.toUpperCase();
	fnameCObj.style.background="yellow";
  
  
  }
  