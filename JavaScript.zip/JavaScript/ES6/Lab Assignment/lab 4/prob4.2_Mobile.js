class Mobile {
			constructor(id,name,cost){
			
				this.mobileid=id;
				this.mobilename=name;
				this.mobilecost=cost;
				
			
			}
			
			printMobiledata(){
			
				console.log(`Mobile Id: ${this.mobileid}
Mobile Name: ${this.mobilename}
Mobile Cost: ${this.mobilecost}`);
			
			if(this.mobiletype!=undefined){
				console.log("Mobile Type :",this.mobiletype);
			}
			
			
			
			}
			}