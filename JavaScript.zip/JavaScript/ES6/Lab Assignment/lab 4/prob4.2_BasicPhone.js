class BasicPhone extends Mobile{

	constructor(id,name,cost,type){
	super(id,name,cost);
	this.mobiletype=type;
	
	}

}