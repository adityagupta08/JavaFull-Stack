 /*
 function showResult()
 {
	var radio;
	
	if(document.getElementById("fnumber").checked)
	{
		radio=document.getElementById("fnumber").value;
	}
	
	else if(document.getElementById("Snumber").checked)
	{
		radio=document.getElementById("Snumber").value;
	}
	
	else if(document.getElementById("result").checked)
	{
		radio=document.getElementById("result").value;
	}
	else if(document.getElementById("add").checked)
	{
		radio=document.getElementById("add").value;
	}
	 
	
	
	window.alert("You selected  "+radio);
	
	
 }
 

   */
 function showResult()
 {
 
	var val;
	var radio = document.getElementsByName("number");
	
	for(var i=0;i<radio.length;i++)
	{
		if(radio[i].checked)
		{
			val=radio[i].value;
		}
		
	}
	
	window.alert(val);
 
 }
 
 

 
 
 