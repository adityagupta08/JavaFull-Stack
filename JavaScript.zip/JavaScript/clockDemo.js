 var timeClear;
 
 
 function startClock()
 {
	var today=new Date();
	var hrs= today.getHours();
	var mins= today.getMinutes();
	var sec= today.getSeconds();
	
	var time= hrs+":"+mins+":"+sec;
	var divSec= document.getElementById("clockSectionId");
	divSec.innerHTML=time;
	timeClear=window.setTimeout("startClock()",1000);
	
 
 }
 
  function stopClock()
 {
	window.clearTimeout(timeClear);
 
 }