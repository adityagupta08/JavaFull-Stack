var http = require('http');
var url = require('url');

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  var q = url.parse(req.url, true).query;
  var txt = q.year + " " + q.month;
  res.end(txt);
}).listen(4600);

// In URL we have given localhost:4600/?year=2017&month=july
// so it takes the year and month and displays in the page
// since it is the object property of req parameter passed in function
// that property name is "url" which holds whats is written after the 
//domain name


/************************************************** */