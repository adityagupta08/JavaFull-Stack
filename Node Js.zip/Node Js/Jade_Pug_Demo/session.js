var express = require('express')
var exp = express()
exp.set("view engine","jade")

exp.use(session({
    cookieName:'uniqid',
    secret:'anyvalue',
    duration:'30*60*1000',
}));

exp.get('/createsession/:name'function(req,res){
    var name=req.params.name;
    console.log(req.params.name);
    req.uniqid.name=name;
})

