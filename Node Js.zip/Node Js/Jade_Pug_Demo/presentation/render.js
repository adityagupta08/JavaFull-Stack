var exp  = require('express')
//instiate express
var view = exp()

view.set("view engine","jade")


view.get("/jade",function(req,res){

//page which we want to dispaly on the browser
res.render("hello");
})

view.listen(4700,()=>{
    console.log("Jade Running");
})