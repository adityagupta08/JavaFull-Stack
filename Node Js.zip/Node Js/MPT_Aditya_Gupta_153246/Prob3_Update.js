var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');


// Use Postman to run this request localhost:5000/update
// Set Headers value as  Key= Content-Type and value = application/json
// In the body of request write in json format as 
//   {
//      "mobId"="1002",
//      "mobName"="Iphone"
//  }
// The mobile.json file get updated with Id=1002 and mobName=Iphone
// previously its name was Micromaxn 
// the result is displayed in the console and as response in postman 


exp.use(parser.json())
exp.route('/update').put((req,res)=>{
console.log(req.body)
    var id= req.body.mobId;
    var name = req.body.mobName;
     var raw = fs.readFileSync('mobile.json')
    var data = JSON.parse(raw);
    for (var d of data) {

        if (d.mobId == id) {
            d.mobName = name;

            res.send(d)
        }

    }
    fs.writeFileSync('mobile.json', JSON.stringify(data));


})

exp.use(cors()).listen(5000, ()=>console.log("RUNNING...."));