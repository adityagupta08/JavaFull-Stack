var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');
//var mongodb = require('mongodb').MongoClient;

// Displaying of mobile belonging to specific Range
// run url as :
// localhost:5000/rest/api/price 
// and it will display mobile whose range is in 10000 to 50000

exp.get('/rest/api/price',(req, res)=>{
    mobarr=[]
   
    var raw = fs.readFileSync('mobile.json')
    var data = JSON.parse(raw);
    for(var d of data){

        if (d.mobPrice>10000 && d.mobPrice<50000 ){
            mobarr.push(d)

        }
}

    res.status(201).send(mobarr);
    console.log(mobarr)
  
})

exp.use(cors()).listen(5000, ()=>console.log("RUNNING...."));