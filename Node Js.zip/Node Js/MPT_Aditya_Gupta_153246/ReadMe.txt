Browser Based
Using Postman


localhost:5000



*******Prob1  --->>to display all mobiles*****

localhost:5000//rest/api/get





******* Prob2 -----> to display mmobile with specific range ******

localhost:5000//rest/api/price





****** Prob3------>  To Update value ************************

 Use Postman to run this request localhost:5000/update   with PUT selected
 Set Headers value as  Key= Content-Type and value = application/json
 In the body of request write in json format as 
   {
      "mobId"="1002",
      "mobName"="Iphone"
  }
 The mobile.json file get updated with Id=1002 and mobName=Iphone
 previously its name was Micromaxn 
 the result is displayed in the console and as response in postman 



************ Prob4 -------> To Add a new Mobile ****************

   Using Postman run localhost:5000/add    with POST selected
     Set Headers value as  Key= Content-Type and value = application/json
  In the Body Of Request type : 

      {
         "mobId": 1008,
       "mobName": "Redmi Note 4",
         "mobPrice": 8999
     }

 This will add new Mobile in mobile.json file and displayed in console as well as sent 
 as a response to postman 