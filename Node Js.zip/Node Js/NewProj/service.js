var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');
var mongodb = require('mongodb').MongoClient;



exp.route('/rest/api/posterr').get((req, res)=>{
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept")
   
    var dat = JSON.parse(fs.readFileSync('read.json'));
    mongodb.connect("mongodb://localhost:27017/test",function(err,DB){
         var DB = DB.db('test');
         DB.collection('JSON').insert(dat,true,function(err,response){
             if(err)
             {
                 throw err;
             }
             res.status(201).send(response);
             console.log(dat);

             

   
         })
    });
    

    
})

exp.use(cors()).listen(3400, ()=>console.log("RUNNING...."));