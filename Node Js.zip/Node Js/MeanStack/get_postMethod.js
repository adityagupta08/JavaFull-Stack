var http = require('http');
var express = require('express');
var exp = express();
var parser=require('body-parser')
var fs = require('fs');
var cors = require('cors');
var mongodb = require('mongodb').MongoClient;

var corsOptions = {
  origin: 'http://localhost:4200',  
}

exp.get('/rest/api/load', cors(), (req, res)=> {
    console.log('Load Invoked....');
    res.send({msg: 'GIVE SOME REST TO WORLD....'});
})

exp.route('/rest/api/get', cors()).get((req, res)=>{
    console.log('GET Invoked....');
    res.send({msg: 'GET WORLD....'});
})

exp.use(parser.json());

exp.route('/rest/api/post', cors()).post((req, res)=>{

    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept")
    console.log(req.body);
    fs.writeFileSync('demo.json', JSON.stringify(req.body));
    mongodb.connect("mongodb://localhost:27017/test",function(err,DB){
         var DB = DB.db('test');
         DB.collection('hello').insert(req.body,true,function(err,DB){
             if(err)
             {
                 throw err;
             }
             res.status(201).send(req.body);
             console.log("Document Inserted");

      
         })
    });
    

    
})

exp.use(parser.json());

exp.route('/rest/api/update', cors()).post((req, res)=>{

    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept")
    console.log(req.body);
    fs.writeFileSync('demo.json', JSON.stringify(req.body));
    mongodb.connect("mongodb://localhost:27017/test",function(err,DB){
         var DB = DB.db('test');
         var query = {name:"aditya"}
         var up = {$set:{name:"Harshita"}}
         DB.collection('hello').updateOne(query,up,function(err,DB){
             if(err)
             {
                 throw err;
             }
             res.status(201).send(DB);
             console.log("Document Inserted");

      
         })
    });
    

    
})



exp.route('/rest/api/poster').get((req, res)=>{
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept")
    console.log("req.body");
    //fs.writeFileSync('demo.json', JSON.stringify(req.body));
    mongodb.connect("mongodb://localhost:27017/test",function(err,DB){
         var DB = DB.db('test');
         DB.collection('hello').find().toArray(function(err,response){
             if(err)
             {
                 throw err;
             }
             res.status(201).send(response);
             console.log("data");

             console.log(response);

   
         })
    });
    

    
})


exp.route('/rest/api/get/:name').get((req, res)=>{
    res.send('Hello World'+req.params['name']);
})
exp.use(cors()).listen(3200, ()=>console.log("RUNNING...."));



