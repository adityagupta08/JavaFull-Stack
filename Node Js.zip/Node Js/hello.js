var http = require('http');

http.createServer(function(req,res){
    res.writeHead(200,{'Content-type':'text/html'});
    // in plave HTML we can write plain for plain text
    res.write('<h1>Hello World Aditya !!</h1>')
     

// URL property holds wpart of the url that comes after domain name

     res.write(req.url) 

    res.end();
}).listen(4500);


