var express = require('express')
var routes = require('./routes/api')
var bodyParser = require('body-parser')
const mongoose= require ('mongoose')
var mongo = require('mongodb');
// setup Express App
var app= express();

mongoose.connect('mongodb://localhost:27017/Ninjago')
mongoose.Promise=global.Promise 

// using a body parser middleware to handle data send 
// in the body of the request through postman
// it is used before routes middleware so that route after getting request  on the postman
// can handle data send in the body
app.use(bodyParser.json());


//inintialize routes
app.use('/api',routes)
// use method is use to use any middleware in our app

//app.use('/api',routes )

// then call localhost:4000/api/ninjas

// app.use('/api', require('./routes/api'))
//will also work and remove var routes = require then 

//Listen Express Request
app.listen(4000,function(){
    console.log("Running")
})