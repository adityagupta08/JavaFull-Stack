var express = require('express')
var router = express.Router();
const mongoose= require ('mongoose')
var mongo = require('mongodb');
var fs = require('fs')
var Ninja = require('../models/ninja')



// get ninjas from db
router.get('/ninjas',function(req,res){
    res.send({type:"GET"})
    console.log("Get Request ")
})

router.post('/ninjas',function(req,res){

        Ninja.create(req.body).then(function(ninja){
            res.send(ninja);
        })
    //
    //Here we Have succefully handled the body of Post request
    console.log(req.body);
    //res.write("Post accepted")
    // res.header("Access-Control-Allow-Origin", "*");
    // res.header("Access-Control-Allow-Headers","Origin, X-Requested-With,Content-Type,Accept")
    // console.log(req.body);
    // fs.writeFileSync('demo.json', JSON.stringify(req.body));
    // mongodb.connect("mongodb://localhost:27017/Ninja",function(err,DB){
    //      var DB = DB.db('test');
    //      DB.collection('ninjas').insert(req.body,true,function(err,DB){
    //          if(err)
    //          {
    //              throw err;
    //          }
    //          res.status(201).send(req.body);
    //          console.log("Document Inserted");

      
    //      })
    // });

    // Sending req body body data back as a response to the post request .
   
})

router.put('/ninjas/:id',function(req,res){
    res.send({type:"PUT"})
})

router.delete('/ninjas/:id',function(req,res){
    res.send({type:"DELETE"})
})

module.exports=router;




// and model is a coolection of all the ninja objects
// Schemas define the structure of objects within the collections and each ninja is a object
// our schemas define structure  of object that is properties of objects