const mongoose= require ('mongoose')
var mongo = require('mongodb');
var schema = mongo.Schema


// how our data gonnna be structured
const Schema = mongoose.Schema  

//creates ninja schema &model 
const NinjaSchema = new Schema({

    name:{
        type:String,
        required:(true,"Name Field is required")
    },
    rank:{
        type:String
    },
    available:{
        type:Boolean,
        default:false
    }

    // add in geo location
})
// It creates Ninja model in MongoDb with ninja as a collection name which wil be coverted into name ninjas
// inside collection objects will be stored n the format of ninjaSchema
const Ninja = mongoose.model('ninja',NinjaSchema);
module.exports=Ninja;