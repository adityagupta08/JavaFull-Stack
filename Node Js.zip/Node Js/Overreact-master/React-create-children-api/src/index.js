import React from 'react';
import ReactDOM from 'react-dom';
import Parent from './Parent';

ReactDOM.render(
    <div>
        <Parent>
            <br />
            <button>register</button>
            <br />
            this is a sample content
        </Parent>
    </div>
    , document.getElementById('root'));
