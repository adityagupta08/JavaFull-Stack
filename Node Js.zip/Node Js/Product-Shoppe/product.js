var http = require('http');
var express = require('express');
var exp = express();
var parser = require('body-parser')
var fs = require('fs');
var cors = require('cors');
var mongodb = require('mongodb').MongoClient;

exp.use(parser.json())

exp.route('/get', cors()).get((req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With,Content-Type,Accept")

    var dat = JSON.parse(fs.readFileSync('products.json'));

    res.status(201).send(dat);
    console.log(dat);
});


exp.route('/addProduct').post((req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With,Content-Type,Accept")
    var raw = fs.readFileSync('products.json')
    var data = JSON.parse(raw);
    console.log(req.body)
    var obj = req.body;
    console.log(obj);
    data.push(obj)
    res.send(data)


    fs.writeFileSync('products.json', JSON.stringify(data));
});




exp.route('/editProduct/:id').put((req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With,Content-Type,Accept")
    console.log(req.body)
    var Pid = req.params['id'];
    var changeId = req.body.id;
    var changeName = req.body.Name;
    var changeDesc = req.body.Description;
    var changePrice = req.body.Price;
    var raw = fs.readFileSync('products.json')
    var data = JSON.parse(raw);
    for (var d of data) {
        if (d.id == Pid) {
            d.id = changeId;
            d.Name = changeName;
            d.Description = changeDesc;
            d.Price = changePrice;

            res.send(data)
        }

    }

    fs.writeFileSync('products.json', JSON.stringify(data));
});

exp.route('/deleteProduct/:id').delete((req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With,Content-Type,Accept")
    var Pid = req.params['id'];
    var raw = fs.readFileSync('products.json')
    var data = JSON.parse(raw);

    for (var i = 0; i < data.length; i++) {
        if (data[i].id == Pid) {
            data.splice(i, 1);

        }

    }
    res.send(data);
    fs.writeFileSync('products.json', JSON.stringify(data));
})





exp.use(cors()).listen(4000, () => console.log("RUNNING...."));