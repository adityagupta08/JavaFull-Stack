var http = require('http');
// var url =require ('')



var express = require('express');

var exp =express();
var x = exp.get('/get',function(req,res){

   res.writeHead(200,{'Content-Type':'text/html'});
 
           res.write("<h1>Some get</h1>"+
           req.query.id*3);
       
           res.end();

});
http.createServer(x).listen(4800);