
var add = require('./lib/add');
console.log("Welcome");

add.addData();
add.getData();


var buff =new  Buffer(18);
console.log(buff);

buff.write("Capgemini");
console.log("\n")
console.log(buff);
console.log("\n")
console.log(buff.toString());
console.log("\n")

console.log(buff.toJSON());
console.log("\n")
var buff1 = new Buffer([4,,5,56,6,,7,7,78,5])
console.log(buff1);


var event = require('events');  // core Moduule of NODE
var myevent =new event.EventEmitter();

//Register of EVENT =="abc"

myevent.on("abc",function(msg,msd){

    console.log("in event abc...",msg,msd);
    setTimeout(function(){
        console.log("After 6 seconds.........")
    },6000)
})

myevent.on("bcd",function(temp){
    console.log("In BCD event....",temp);
})

myevent.emit("abc","Capgemini.......","good Company")
myevent.emit("bcd","Node Js")