var func={

productArray:[],

newProducts:function(id,name,price)
{
    this.proId=id;
    this.proName=name;
    this.proPrice=price;
  
    this.addProducts();
},


addProducts:function()
{
    var prod={"Id":this.proId,"Name":this.proName,"Price":this.proPrice}
    this.productArray.push(prod);
},


showProducts:function()
{

    for(var i=0;i<this.productArray.length;i++)
    {
        console.log("Product Id :" + this.productArray[i].Id);
        console.log("Product Name :" + this.productArray[i].Name);
        console.log("Product Price :" + this.productArray[i].Price);
        console.log("*****************")

    }
},

sortId:function(){

    this.productArray.sort(function(a,b){

        return a.Price-b.Price;
       
    })
    
}

}

module.exports=func;

