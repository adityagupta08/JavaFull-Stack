
var pro =  require('./tryProduct')

pro.newProducts(102,"rice",908);
pro.newProducts(103,"ponds",234);
pro.newProducts(104,"wheat",23);

pro.showProducts();
pro.sortId();
pro.showProducts();