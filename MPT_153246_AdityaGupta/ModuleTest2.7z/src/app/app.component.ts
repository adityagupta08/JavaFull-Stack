import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import {Mobile} from './mobile';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  // INISTIALISING HTTPSERVICE IN CONSTRUCOTR
  
  constructor(private httpservice:HttpClient){}
  mobileArray:Mobile[];



ngOnInit(){
  
  
  // FETCHING DATA FROM JSON FILE THROUGH  HTTPSERVICE 
  // FILE IS PRESENT IN ASSETS FOLDER



  this.httpservice.get('/assets/mobile.json').subscribe(

    data=>{

      this.mobileArray= data as Mobile[];

    },
    (err: HttpErrorResponse)=>{
      console.log(err.message);
    }


  )
}

// REMOVING THE PARTICULAR ROW ON CLICKING OF DELETE BUTTON

RemoveData(i){
  this.mobileArray.splice(i,1);
  
}

// SORTING IN ASCENDING ORDER OF TABLE DATA ON CLCIKING OF MOBILOE ID BUTTON

 sortId(){
           this.mobileArray.sort((a,b)=>a.mobId-b.mobId);
       }



 // SORTING IN ASCENDING ORDER OF TABLE DATA ON CLICKING OF MOBILE NAME BUTTON     

       sortName() {
           this.mobileArray.sort(function (a, b) {
               var x = a.mobName.toLowerCase();
               var y = b.mobName.toLowerCase();
               if (x < y) { return -1; }
               if (x > y) { return 1; }
               return 0;
           }
           )
       }


    // SORTING IN ASCENDING ORDER OF TABLE DATA ON CLICKING OF MOBILE PRICE BUTTON   

        sortPrice(){
           this.mobileArray.sort((a,b)=>a.mobPrice-b.mobPrice);
       }


}
