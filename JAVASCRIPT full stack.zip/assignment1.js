var jsonarray= [];

var addRow = function ()
{

	var cid = document.getElementById("txtcountryid").value;
	
	var cname= document.getElementById("txtcountryname").value;
	var cpop=  document.getElementById("txtcountrypopulation").value;
	
	
	if(cid=="" || cname=="" || cpop=="")
	{
		document.getElementById("warning").innerHTML='<div class="alert alert-danger"><strong>Danger!</strong> Fill all the Fields.</div>';
		return false;
	}
	
	
	function country(id,name,pop){
	
		this.id=id;
		this.name=name;
		this.pop=pop;
	}
	
	
	
	var countryObj = new country(cid,cname,cpop);
	
	for(var i of jsonarray)
	{
		if((i.id==cid) || (i.name=cname))
		{
			document.getElementById("warning").innerHTML='<div class="alert alert-danger"><strong>Danger!</strong> Country Id or Country name cannot be Same.</div>';
			return false;
		}
		
	}
	
	jsonarray.push(countryObj);
	insertvalue(countryObj);
	document.getElementById("txtcountryid").value="";
    document.getElementById("txtcountryname").value="";
    document.getElementById("txtcountrypopulation").value="";
	
	

}

function insertvalue(countryObj)
{
	var table= document.getElementById("table1");
	
	var row=table.insertRow(table.rows.length);
	
	var cell1 = row.insertCell(0);
	var ele1 = document.createElement("p");
	ele1.innerHTML=" "+countryObj.id;
	cell1.appendChild(ele1);
	
	var cell2 = row.insertCell(1);
	var ele2 = document.createElement("p");
	ele2.innerHTML=" "+countryObj.name;
	cell2.appendChild(ele2);
	
	var cell3 = row.insertCell(2);
	var ele3 = document.createElement("p");
	ele3.innerHTML=" "+countryObj.pop;
	cell3.appendChild(ele3);
	
	var cell4 = row.insertCell(3);
	var ele4 = document.createElement("button");
	var t = document.createTextNode("Remove");
	ele4.appendChild(t);
	cell4.appendChild(ele4);
	
	ele4.addEventListener("click",function(){
		var index = row.rowIndex;
		table.deleteRow(index);
		jsonarray.splice(index-1,1);
		delete jsonarray(index-1);
		
		
	
	});
	

	
	

}


























