var countryList=[]

var addCountry = function(){

    var cid = document.getElementById("txtcountryid").value;
    var cname = document.getElementById("txtcountryname").value;
    var cpop = document.getElementById("txtcountrypopulation").value;

    if(cid=="" || cname=="" || cpop==""){
        document.getElementById("warning").innerHTML='<div class="alert alert-danger"><strong>Danger!</strong> Fill all the Fields.</div>';
        return false;
    }
    

    var countryClass = function(id,name,pop){
        this.id=id;
        this.name=name;
        this.pop=pop;
    }
	
	

    var countryObj = new countryClass(cid,cname,cpop);
	
	for(var i of countryList){
        if(i.id==cid){
             alert("same data");
              return false;
        }
    }
    
    countryList.push(countryObj);
	
	
    insertValue(countryObj);
    document.getElementById("txtcountryid").value="";
    document.getElementById("txtcountryname").value="";
    document.getElementById("txtcountrypopulation").value="";

    
}



var insertValue = function(countryObj){
    var table = document.getElementById("table1");
    var table_len = table.rows.length;
    var row = table.insertRow(table_len);

    var cell1 = row.insertCell(0);
    var element1 = document.createElement("p");
    element1.innerHTML=" "+countryObj.id;
    cell1.appendChild(element1);


    var cell2 = row.insertCell(1);
    var element2 = document.createElement("p");
    element2.innerHTML=" "+countryObj.name;
    cell2.appendChild(element2);

    var cell3 = row.insertCell(2);
    var element3 = document.createElement("p");
    element3.innerHTML=" "+countryObj.pop;
    cell3.appendChild(element3);

    var cell4 = row.insertCell(3);
    var element4 = document.createElement("button");
    var t=document.createTextNode("Remove");
    element4.appendChild(t);
    cell4.appendChild(element4);
    element4.addEventListener('click',function(){
        var index = row.rowIndex;
        table.deleteRow(index);
        countryList.splice(index-1,1);
        delete countryList[index-1];
    });

}

