 var addRow = function(){
    var countryId = document.getElementById("txtcountryid").value;
    var countryName = document.getElementById("txtcountryname").value;
    var countryPopulation = document.getElementById("txtcountrypopulation").value;
    
    var table2 = document.getElementById('table1');
    var row_len = (table2.rows.length);
    var row = table2.insertRow(row_len).outerHTML = "<tr id='row"+row_len+"'><td id='txtcountryid"+row_len+"'>"+countryId+"</td><td id='txtcountryname"+row_len+"'>"+countryName+"</td><td id='txtcountryPopulation"+row_len+"'>"+countryPopulation+"</td><td><input type='button' id='btnremove' value='Remove' onClick='return delete1("+row_len+")'/></td></tr>";  
};

var delete1 = function(no){
    document.getElementById("row"+no+"").outerHTML="";
}