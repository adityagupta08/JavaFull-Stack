var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url,function(err,db){
    if(err) throw err
    var dbo = db.db("ProductDb");

    // create Collection
    dbo.createCollection("products",function(err,res){
        if(err)throw err;
        console.log("collection Created");
 });

     var myobj1 = [
   {ProductId:"101",ProductName:"Ponds",ProductCost:230,ProductDescription:"It is a Talcum Powder"},
   {ProductId:"102",ProductName:"Navratan",ProductCost:130,ProductDescription:"It is a oil"},
   {ProductId:"103",ProductName:"WildStone",ProductCost:120,ProductDescription:"It is a Soap"}
  ];
   dbo.collection("products").insertMany(myobj1, function(err, res) {
    if (err) throw err;
    console.log("Number of documents inserted: " + res.insertedCount);
   // db.close();
  });

})