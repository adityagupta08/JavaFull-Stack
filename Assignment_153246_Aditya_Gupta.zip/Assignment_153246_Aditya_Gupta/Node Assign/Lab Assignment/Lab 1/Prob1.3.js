var http = require('http');

var fs = require('fs');

fs.writeFile('Prob1.3.html',"<h1>Hello</h1> <br/>From Prob1.3  Created File through Node!",
function(err){

    if(err) throw err;
    console.log("Saved File !!");
});

http.createServer(function(req,res){
    fs.readFile('Prob1.3.html',function(err,data){
          res.writeHead(200,{'Content-Type':'text/html'});
 
           res.write(data);

           
           
           res.end();
    })

}).listen(4900);