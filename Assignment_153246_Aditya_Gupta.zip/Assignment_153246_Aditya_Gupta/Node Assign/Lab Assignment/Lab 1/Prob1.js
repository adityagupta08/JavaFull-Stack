var Employee =["Rahul Vikas","Aditya Bokade","AnjuLata Tembhare","Vaishali Shrivastav","John Christopher","Susun Ibach"]


for(emp of Employee)
{
    console.log(emp);
}