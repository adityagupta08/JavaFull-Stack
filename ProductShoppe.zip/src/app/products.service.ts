import { Injectable } from '@angular/core';
import { Product } from "./products";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  private _urlGet = "http://127.0.0.1:4000/get";
  private _urlPost = "http://127.0.0.1:4000/addProduct";
  private _urlPut = "http://127.0.0.1:4000/editProduct/";
  private _urlDelete = "http://127.0.0.1:4000/deleteProduct/";

  constructor(private _http:HttpClient) { }


getProducts():Observable<Product[]> {
  return this._http.get<Product[]>(this._urlGet);
}

addProducts(data):Observable<Product[]>{

  return this._http.post<Product[]>(this._urlPost,data);
}

editProduct(data,id):Observable<Product[]>{
  return this._http.put<Product[]>(this._urlPut+id , data);
}

deleteProduct(id):Observable<Product[]>{
  return this._http.delete<Product[]>(this._urlDelete+id);
}


}
