import { Component, OnInit } from '@angular/core';
import { ProductsService } from './products.service';
import { FormsModule } from "@angular/forms";
import {NgForm} from '@angular/forms'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
      p: number = 1;
      pId: number;
      pName: string;
      pDes: string;
      pPrice: number;
      strObj:string
      proId:number;
      proName:string;
      proDes:string;
      proPrice:number;

      products = []

      constructor(private _prodServ: ProductsService) { }

          ngOnInit() {

            this._prodServ.getProducts().subscribe(

              data => (this.products = data)
            );
          }
            clearData(f:NgForm)
              {
                f.resetForm();
                this.pId = null;
                this.pPrice = null;
                this.pName = this.pDes = "";
              }

          addProduct(f:NgForm)
              {
                this.strObj='{"id":' +
                  this.pId +
                  ',"Name":"' +
                  this.pName +
                  '","Description":"' +
                  this.pDes +
                  '","Price":' +
                  this.pPrice +
                  "}";
                  this._prodServ.addProducts(JSON.parse(this.strObj)).subscribe(
                    data=>(this.products=data)
                  )
                  f.resetForm();
                  this.clearData(f);
                  
            }


            editData(Id:number)
            {
              for(var p of this.products)
                {
                  if(p.id==Id)
                    {
                      this.proId=p.id;
                      this.proName=p.Name;
                      this.proDes=p.Description;
                      this.proPrice=p.Price;
                    }
                }

            }

            editProduct()
            {
              this.strObj='{"id":' +
                  this.proId +
                  ',"Name":"' +
                  this.proName +
                  '","Description":"' +
                  this.proDes +
                  '","Price":' +
                  this.proPrice +
                  "}";
              this._prodServ.editProduct(JSON.parse(this.strObj),this.proId).subscribe(
                data=>(this.products=data)
              )
              


            }

            deletetData(id:number)
            {
              this._prodServ.deleteProduct(id).subscribe(
                data=>(this.products=data)
              );
            }
}
